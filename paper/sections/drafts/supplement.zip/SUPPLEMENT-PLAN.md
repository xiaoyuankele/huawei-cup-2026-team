# 最终论文附件方案（草稿）

本文件是附件封卷方案，不代表其中所有结果已经通过独立评审。具体数值以生成时的 manifest、run_id 和 SHA256 为准。

当前 `paper/claim-ledger.csv` 有 38 条主张，状态均为 `DRAFT`；因此本方案中的索引和结果表默认是证据追踪材料，不自动等同于已验收结果。

## 推荐提交结构

```text
deliverables/final/
├── final_paper.pdf
├── supplement.zip
├── reproducibility.zip
├── MANIFEST.sha256
└── README-submission.md
```

## supplement.zip

### S1_model_spec.xlsx

建议工作表：

- `README`：表格来源、状态定义、单位和公开范围
- `indicator_dictionary`：原始字段、最终入模字段、方向、单位、变换、缺失处理
- `critic_weights`：指标权重、拟合集、归一化边界和权重和
- `conflict_rules`：五维分组、低/高阈值、冲突类别和 lambda 网格
- `mixture_model`：17 域单纯形、ILR/零替换、训练/验证/外推角色、正则化参数
- `q2_q3_parameters`：标度律、质量映射、预算、质量成本和求解器参数
- `q4_protocol`：仅在 Q4 纳入正式答卷时提供

### S2_data_provenance.xlsx

每行对应一个数据文件或 manifest 输入，至少包含：

`dataset_id, manifest_path, role, rows, columns, scale, observed_or_estimated, train_holdout_extrapolation, join_key, missing_rule, sha256, public_or_controlled, limitations`

原始数据不复制进工作簿；受控数据只记录路径元数据和哈希。

### S3_full_results.zip

建议按问题分目录：

- `q1/`：领域分数、语料分数、完整权重、冲突覆盖率、阈值和 lambda 敏感性
- `q1_mixture/`：逐 Loss 指标、A6/A7 同尺度外验、A8/A9 配对诊断、A12--A15 外推审计
- `q2/`：E1--E4 条件结果和边界说明
- `q3/`：M0/M1/M2 情景、预算复核、支持域、后悔值和负 Loss 诊断
- `q4/`：若纳入主答卷，另列 C8 前沿、时间外验证和情景表

每个目录都应有 `README.md`，注明“观测、半合成、估算、情景”身份。

### S4_claim_evidence_boundary.csv

从 `paper/claim-ledger.csv` 导出读者版矩阵，字段建议为：

`claim_id, paper_location, claim, run_id, data_manifest, figure_or_table, evidence_level, status, observed_or_estimated, allowed_interpretation, forbidden_extrapolation, reviewer, notes`

现有 `DRAFT`、`REVIEW`、`REVIEW_BLOCKED` 和 `EXPLORATORY` 状态必须保留。

### S5_diagnostics.pdf

只收录能够帮助复核的补充图：残差和逐目标指标、交叉验证折、外部验证、阈值/lambda 敏感性、Aitchison 支持域、Q3 完整单纯形负 Loss 诊断，以及 Q4 的短样本时间外验证。

## reproducibility.zip

至少包含：

- `README-reproduce.md`
- `requirements` 或锁定环境说明
- 编译论文和重建图表的入口脚本
- `configs/`、`scripts/`、运行 manifest 和预期输出
- `MANIFEST.sha256`
- 一个不含原始敏感数据的最小 smoke test

复现包只能复现公开派生表和图件；无法公开的数据必须通过 manifest、版本和哈希说明。

## 状态规则

- `VERIFIED`：已完成独立复核并可作为正式结果
- `INTERNAL`：仅完成代码或代数自洽检查
- `CONDITIONAL`：依赖明确假设的情景结果
- `EXPLORATORY`：探索性结果，不能写成已验证规律
- `REVIEW_BLOCKED`：存在未关闭的独立评审或证据问题

任何附件都不能把 `CONDITIONAL`、`EXPLORATORY` 或 `REVIEW_BLOCKED` 改写成 `VERIFIED`。
