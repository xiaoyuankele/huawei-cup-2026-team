# 正式论文源文件与附件引用边界

本文件用于封卷前锁定正式源文件，避免历史稿、阶段稿和候选图件被误认为最终结果。

## 正式主稿

以下文件是最终论文主入口或由主入口直接装配的正文来源：

- `main.tex`
- `sections/q1-quality-evaluation.tex`
- `sections/q1-conflict-resolution.tex`
- `sections/q1-mixture-loss.tex`
- `sections/drafts/q2-complete.tex`
- `sections/drafts/q3-resource-optimization.tex`
- `sections/drafts/q3-conditional-results.tex`（仅当 `main.tex` 当前版本实际引用）
- `sections/references.tex`

正式封卷时，以 `main.tex` 中实际出现的 `\input` 为准；本清单不替代编译检查。

## 仅作追溯的文件

以下类型的文件不应直接放进最终附件包，除非明确标记为历史版本：

- `sections/*_current-stage*`
- `sections/*_standalone*`
- `sections/drafts/` 中未被 `main.tex` 引用的阶段稿
- 连字符与下划线命名的重复旧稿
- 标记为 `candidate`、`REVIEW_BLOCKED` 或 `EXPLORATION_ONLY` 的候选材料

## 附件的引用规则

1. 附件中的每个数字必须能够回链到 `run_id`、数据 manifest、源文件路径和 SHA256。
2. `DRAFT`、`REVIEW`、`REVIEW_BLOCKED` 和 `EXPLORATORY` 状态必须原样保留，不能在附件中改写为“已验证”。
3. A12--A15、B10 等估算或外推数据必须单独标记，不能与实测数据混列而不加说明。
4. Q2/Q3 的条件情景不能标成全局最优；Q4 若不并入主稿，应作为独立包并在总清单中注明。
5. 原始文本、原始附件、个人信息、账号、密钥和受控路径不进入公开附件。

## 封卷前检查

- [ ] `main.tex` 的所有 `\input` 都已在本清单中说明
- [ ] `paper/sections/abstract.tex` 等未被主入口引用的文件已标记为旧稿或移出上传包
- [ ] 论文正文、补充表、图件 manifest 和 claim ledger 的数字一致
- [ ] 附件包已生成 `MANIFEST.sha256`
- [ ] 独立复核完成后，才将附件状态改为 `PACKAGE_ACCEPTED`
