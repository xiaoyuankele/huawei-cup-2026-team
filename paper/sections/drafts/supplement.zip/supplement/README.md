# Supplementary Tables Package

This package contains public derived tables and provenance metadata for the paper review workflow.

- `Supplementary_Tables.xlsx`: Q1 indicators, weights, conflict thresholds, Q2/Q3 parameter summary, and public data provenance.
- `S2_runs.csv`: experiment index export with original run statuses.
- `S4_claim_evidence_boundary.csv`: claim ledger export with review status preserved.
- `supplement_appendix.pdf`: short reviewer-facing overview of data roles, frozen parameters, diagnostics, and claim boundaries.

The package does not contain raw text, controlled attachments, private paths, credentials, or unreviewed data copies. `DRAFT`, `REVIEW`, `REVIEW_BLOCKED`, and exploratory statuses are intentionally retained.
