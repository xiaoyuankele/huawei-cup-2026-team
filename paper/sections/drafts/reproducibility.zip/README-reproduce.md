# Public Reproducibility Package

This package provides a metadata-only smoke test for the supplementary evidence tables. It is intended to verify the public attachment structure without exposing raw text, controlled attachments, credentials, or private storage paths.

## Contents

- `scripts/reproduce_public.py`: standard-library smoke test.
- `configs/reproduce_public.json`: expected snapshot counts and status vocabulary.
- `metadata/S2_runs.csv`: public run-index export.
- `metadata/S4_claim_evidence_boundary.csv`: public claim/evidence export.
- `metadata/CANONICAL_SOURCES.md`: source-locking and evidence-boundary rules.
- `MANIFEST.sha256`: SHA256 checksums for this package.

## Run

From this directory, run:

```text
python scripts/reproduce_public.py
```

The test checks that the two public CSV exports are readable, have the expected row counts, retain status fields, and match the declared SHA256 values. It does not rebuild model fits or access controlled data.

## Interpretation

This is a package-integrity and evidence-traceability check. A passing smoke test does not constitute independent scientific validation. The source records currently retain `DRAFT`, `REVIEW`, `REVIEW_BLOCKED`, and exploratory states.
