"""Metadata-only smoke test for the public supplementary package."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "configs" / "reproduce_public.json").read_text(encoding="utf-8"))


def read_rows(relative_path: str) -> list[dict[str, str]]:
    path = ROOT / relative_path
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    runs = read_rows("metadata/S2_runs.csv")
    claims = read_rows("metadata/S4_claim_evidence_boundary.csv")
    assert len(runs) == CONFIG["expected_runs"], (len(runs), CONFIG["expected_runs"])
    assert len(claims) == CONFIG["expected_claims"], (len(claims), CONFIG["expected_claims"])

    allowed = set(CONFIG["allowed_statuses"])
    for label, rows in (("runs", runs), ("claims", claims)):
        assert rows, f"{label} is empty"
        assert "status" in rows[0], f"{label} has no status column"
        unknown = sorted({row["status"] for row in rows if not row["status"] or row["status"] not in allowed})
        assert not unknown, (label, unknown)

    manifest = ROOT / "MANIFEST.sha256"
    checks = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        actual = sha256(ROOT / relative)
        assert actual == expected, (relative, expected, actual)
        checks += 1

    print(f"PASS: {len(runs)} runs, {len(claims)} claims, {checks} SHA256 records")
    print("PASS: metadata-only; no raw or controlled data accessed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
